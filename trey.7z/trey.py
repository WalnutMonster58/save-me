import tkinter
import os
import webbrowser
from time import sleep
import random



while True:
    webbrowser.open('https://www.youtube.com/watch?v=0U2zJOryHKQ')
